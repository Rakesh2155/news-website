import React, { createContext, useContext, useReducer, useEffect, useCallback, useRef } from 'react';
import { Article, Category, Language, NewsState } from '../types';
import { fetchNews, fetchTrendingNews } from '../api/newsApi';

// Initial state
const initialState: NewsState = {
  articles: [],
  trending: [],
  loading: false,
  error: null,
  searchQuery: '',
  selectedCategory: null,
  selectedLanguage: 'english',
  lastUpdated: null,
};

// Action types
type NewsAction =
  | { type: 'FETCH_NEWS_START' }
  | { type: 'FETCH_NEWS_SUCCESS'; payload: Article[] }
  | { type: 'FETCH_TRENDING_SUCCESS'; payload: Article[] }
  | { type: 'FETCH_NEWS_FAILURE'; payload: string }
  | { type: 'SET_SEARCH_QUERY'; payload: string }
  | { type: 'SET_CATEGORY'; payload: Category | null }
  | { type: 'SET_LANGUAGE'; payload: Language }
  | { type: 'SET_LAST_UPDATED'; payload: Date };

// Reducer
const newsReducer = (state: NewsState, action: NewsAction): NewsState => {
  switch (action.type) {
    case 'FETCH_NEWS_START':
      return { ...state, loading: true, error: null };
    case 'FETCH_NEWS_SUCCESS':
      return { ...state, loading: false, articles: action.payload };
    case 'FETCH_TRENDING_SUCCESS':
      return { ...state, trending: action.payload };
    case 'FETCH_NEWS_FAILURE':
      return { ...state, loading: false, error: action.payload };
    case 'SET_SEARCH_QUERY':
      return { ...state, searchQuery: action.payload };
    case 'SET_CATEGORY':
      return { ...state, selectedCategory: action.payload };
    case 'SET_LANGUAGE':
      return { ...state, selectedLanguage: action.payload };
    case 'SET_LAST_UPDATED':
      return { ...state, lastUpdated: action.payload };
    default:
      return state;
  }
};

// Context
interface NewsContextType {
  state: NewsState;
  fetchNewsByCategory: (category?: Category) => Promise<void>;
  fetchNewsBySearch: (query: string) => Promise<void>;
  setCategory: (category: Category | null) => void;
  setLanguage: (language: Language) => void;
  setSearchQuery: (query: string) => void;
  refreshNews: () => Promise<void>;
}

const NewsContext = createContext<NewsContextType | undefined>(undefined);

// Provider component
export const NewsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(newsReducer, initialState);
  const autoUpdateIntervalRef = useRef<number | null>(null);

  // Function to refresh news
  const refreshNews = useCallback(async () => {
    try {
      const articles = await fetchNews(state.selectedCategory || undefined, state.selectedLanguage, state.searchQuery);
      dispatch({ type: 'FETCH_NEWS_SUCCESS', payload: articles });

      const trending = await fetchTrendingNews(state.selectedLanguage);
      dispatch({ type: 'FETCH_TRENDING_SUCCESS', payload: trending });
      
      dispatch({ type: 'SET_LAST_UPDATED', payload: new Date() });
      
      console.log('News updated at:', new Date().toLocaleTimeString());
    } catch (error) {
      dispatch({ 
        type: 'FETCH_NEWS_FAILURE', 
        payload: error instanceof Error ? error.message : 'An unknown error occurred' 
      });
    }
  }, [state.selectedCategory, state.selectedLanguage, state.searchQuery]);

  // Fetch initial news and trending news
  useEffect(() => {
    const loadInitialData = async () => {
      dispatch({ type: 'FETCH_NEWS_START' });
      try {
        const articles = await fetchNews(state.selectedCategory || undefined, state.selectedLanguage);
        dispatch({ type: 'FETCH_NEWS_SUCCESS', payload: articles });

        const trending = await fetchTrendingNews(state.selectedLanguage);
        dispatch({ type: 'FETCH_TRENDING_SUCCESS', payload: trending });
        
        dispatch({ type: 'SET_LAST_UPDATED', payload: new Date() });
      } catch (error) {
        dispatch({ 
          type: 'FETCH_NEWS_FAILURE', 
          payload: error instanceof Error ? error.message : 'An unknown error occurred' 
        });
      }
    };

    loadInitialData();
  }, [state.selectedLanguage]);

  // Set up auto-update interval
  useEffect(() => {
    // Clear any existing interval
    if (autoUpdateIntervalRef.current) {
      window.clearInterval(autoUpdateIntervalRef.current);
    }
    
    // Set new interval - update every 5 minutes (300000 ms)
    autoUpdateIntervalRef.current = window.setInterval(() => {
      refreshNews();
    }, 300000);
    
    // Clean up on unmount
    return () => {
      if (autoUpdateIntervalRef.current) {
        window.clearInterval(autoUpdateIntervalRef.current);
      }
    };
  }, [refreshNews]);

  // Fetch news by category - wrapped in useCallback to prevent recreation on each render
  const fetchNewsByCategory = useCallback(async (category?: Category) => {
    dispatch({ type: 'FETCH_NEWS_START' });
    try {
      const articles = await fetchNews(category, state.selectedLanguage, state.searchQuery);
      dispatch({ type: 'FETCH_NEWS_SUCCESS', payload: articles });
      dispatch({ type: 'SET_LAST_UPDATED', payload: new Date() });
    } catch (error) {
      dispatch({ 
        type: 'FETCH_NEWS_FAILURE', 
        payload: error instanceof Error ? error.message : 'An unknown error occurred' 
      });
    }
  }, [state.selectedLanguage, state.searchQuery]);

  // Fetch news by search query - wrapped in useCallback
  const fetchNewsBySearch = useCallback(async (query: string) => {
    dispatch({ type: 'SET_SEARCH_QUERY', payload: query });
    dispatch({ type: 'FETCH_NEWS_START' });
    try {
      const articles = await fetchNews(state.selectedCategory || undefined, state.selectedLanguage, query);
      dispatch({ type: 'FETCH_NEWS_SUCCESS', payload: articles });
      dispatch({ type: 'SET_LAST_UPDATED', payload: new Date() });
    } catch (error) {
      dispatch({ 
        type: 'FETCH_NEWS_FAILURE', 
        payload: error instanceof Error ? error.message : 'An unknown error occurred' 
      });
    }
  }, [state.selectedCategory, state.selectedLanguage]);

  // Set category - wrapped in useCallback
  const setCategory = useCallback((category: Category | null) => {
    dispatch({ type: 'SET_CATEGORY', payload: category });
    fetchNews(category || undefined, state.selectedLanguage, state.searchQuery)
      .then(articles => {
        dispatch({ type: 'FETCH_NEWS_SUCCESS', payload: articles });
        dispatch({ type: 'SET_LAST_UPDATED', payload: new Date() });
      })
      .catch(error => {
        dispatch({ 
          type: 'FETCH_NEWS_FAILURE', 
          payload: error instanceof Error ? error.message : 'An unknown error occurred' 
        });
      });
  }, [state.selectedLanguage, state.searchQuery]);

  // Set language - wrapped in useCallback
  const setLanguage = useCallback((language: Language) => {
    dispatch({ type: 'SET_LANGUAGE', payload: language });
  }, []);

  // Set search query - wrapped in useCallback
  const setSearchQuery = useCallback((query: string) => {
    dispatch({ type: 'SET_SEARCH_QUERY', payload: query });
  }, []);

  return (
    <NewsContext.Provider
      value={{
        state,
        fetchNewsByCategory,
        fetchNewsBySearch,
        setCategory,
        setLanguage,
        setSearchQuery,
        refreshNews,
      }}
    >
      {children}
    </NewsContext.Provider>
  );
};

// Custom hook to use the NewsContext
export const useNews = () => {
  const context = useContext(NewsContext);
  if (context === undefined) {
    throw new Error('useNews must be used within a NewsProvider');
  }
  return context;
};