export interface Article {
  id: string;
  title: string;
  description: string;
  content: string;
  url: string;
  image: string;
  publishedAt: string;
  source: {
    name: string;
    url: string;
  };
  category: string;
  aiSummary?: string;
  language: string;
}

export type Category = 
  | 'politics'
  | 'business'
  | 'technology'
  | 'sports'
  | 'entertainment'
  | 'regional'
  | 'trending';

export type Language = 'english' | 'hindi' | 'tamil' | 'telugu' | 'bengali' | 'marathi';

export interface NewsState {
  articles: Article[];
  trending: Article[];
  loading: boolean;
  error: string | null;
  searchQuery: string;
  selectedCategory: Category | null;
  selectedLanguage: Language;
  lastUpdated: Date | null;
}