import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Clock, User, ArrowLeft, Share2 } from 'lucide-react';
import { Article } from '../types';
import { mockArticles } from '../api/mockData';
import Chatbot from '../components/Chatbot';

const ArticlePage: React.FC = () => {
  const { articleId } = useParams<{ articleId: string }>();
  const [article, setArticle] = useState<Article | null>(null);
  const [loading, setLoading] = useState(true);
  const [relatedArticles, setRelatedArticles] = useState<Article[]>([]);

  useEffect(() => {
    // In a real app, this would be an API call
    const fetchArticle = () => {
      setLoading(true);
      setTimeout(() => {
        const foundArticle = mockArticles.find(a => a.id === articleId) || null;
        setArticle(foundArticle);
        
        if (foundArticle) {
          // Find related articles from the same category
          const related = mockArticles
            .filter(a => a.category === foundArticle.category && a.id !== foundArticle.id)
            .slice(0, 3);
          setRelatedArticles(related);
        }
        
        setLoading(false);
      }, 500);
    };

    fetchArticle();
  }, [articleId]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="container mx-auto px-4 py-10">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          <p>Article not found. The article may have been removed or the URL is incorrect.</p>
        </div>
        <div className="mt-6">
          <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-800">
            <ArrowLeft size={16} className="mr-2" />
            Back to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-10">
      {/* Article Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-6">
          <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4">
            <ArrowLeft size={16} className="mr-2" />
            Back to Home
          </Link>
          
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{article.title}</h1>
          
          <div className="flex flex-wrap items-center text-gray-600 mb-4 gap-4">
            <span className="inline-block bg-blue-600 text-white text-xs font-semibold px-2 py-1 rounded">
              {article.category.charAt(0).toUpperCase() + article.category.slice(1)}
            </span>
            <div className="flex items-center">
              <User size={16} className="mr-1" />
              <span>{article.source.name}</span>
            </div>
            <div className="flex items-center">
              <Clock size={16} className="mr-1" />
              <span>{formatDate(article.publishedAt)}</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Featured Image */}
            <div className="mb-6">
              <img
                src={article.image}
                alt={article.title}
                className="w-full h-auto rounded-lg shadow-md"
              />
            </div>
            
            {/* AI Summary */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <h2 className="text-lg font-semibold text-blue-800 mb-2">AI Summary</h2>
              <p className="text-gray-700">{article.aiSummary}</p>
            </div>
            
            {/* Article Content */}
            <div className="prose max-w-none">
              <p className="text-lg text-gray-700 mb-4">{article.description}</p>
              <p className="text-gray-700 whitespace-pre-line">{article.content}</p>
              
              {/* Source Link */}
              <div className="mt-8 pt-4 border-t border-gray-200">
                <p className="text-gray-600">
                  Source: <a href={article.source.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{article.source.name}</a>
                </p>
              </div>
              
              {/* Share Buttons */}
              <div className="mt-6 flex items-center">
                <span className="text-gray-700 mr-3">Share:</span>
                <div className="flex space-x-2">
                  <button className="p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700">
                    <Share2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Related Articles */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
              <h2 className="text-xl font-bold mb-4 border-b pb-2">Related Articles</h2>
              <div className="space-y-4">
                {relatedArticles.map(relatedArticle => (
                  <div key={relatedArticle.id} className="border-b pb-4 last:border-b-0">
                    <Link to={`/article/${relatedArticle.id}`} className="group">
                      <h3 className="font-medium text-gray-800 group-hover:text-blue-600 transition-colors">
                        {relatedArticle.title}
                      </h3>
                      <div className="flex items-center text-sm text-gray-500 mt-1">
                        <Clock size={14} className="mr-1" />
                        <span>{formatDate(relatedArticle.publishedAt)}</span>
                      </div>
                    </Link>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Language Indicator */}
            <div className="bg-white rounded-lg shadow-sm p-4">
              <h2 className="text-xl font-bold mb-2 border-b pb-2">Article Language</h2>
              <p className="text-gray-700 capitalize">{article.language}</p>
            </div>
          </div>
        </div>
      </div>
      
      <Chatbot />
    </div>
  );
};

export default ArticlePage;