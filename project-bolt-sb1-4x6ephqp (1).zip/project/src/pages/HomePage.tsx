import React, { useEffect } from 'react';
import { useNews } from '../context/NewsContext';
import TrendingNews from '../components/TrendingNews';
import CategoryFilter from '../components/CategoryFilter';
import NewsGrid from '../components/NewsGrid';
import Chatbot from '../components/Chatbot';
import NewsUpdateIndicator from '../components/NewsUpdateIndicator';

const HomePage: React.FC = () => {
  const { state, setCategory } = useNews();

  useEffect(() => {
    // Reset category when landing on home page
    // Only run this effect once when the component mounts
    setCategory(null);
  }, []); // Empty dependency array to run only on mount

  return (
    <div className="min-h-screen bg-gray-50">
      <TrendingNews articles={state.trending} />
      <CategoryFilter 
        selectedCategory={state.selectedCategory} 
        onSelectCategory={setCategory} 
      />
      <NewsUpdateIndicator />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">
          {state.selectedCategory 
            ? `${state.selectedCategory.charAt(0).toUpperCase() + state.selectedCategory.slice(1)} News` 
            : 'Latest News'}
        </h1>
        
        <NewsGrid 
          articles={state.articles} 
          loading={state.loading} 
          error={state.error} 
        />
      </div>
      
      <Chatbot />
    </div>
  );
};

export default HomePage;