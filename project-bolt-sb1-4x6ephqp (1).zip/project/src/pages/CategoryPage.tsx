import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useNews } from '../context/NewsContext';
import CategoryFilter from '../components/CategoryFilter';
import NewsGrid from '../components/NewsGrid';
import Chatbot from '../components/Chatbot';
import NewsUpdateIndicator from '../components/NewsUpdateIndicator';
import { Category } from '../types';

const CategoryPage: React.FC = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const { state, setCategory } = useNews();

  useEffect(() => {
    if (categoryId && isCategoryValid(categoryId)) {
      setCategory(categoryId as Category);
    }
  }, [categoryId]); // Only depend on categoryId, not setCategory

  const isCategoryValid = (category: string): category is Category => {
    return ['politics', 'business', 'technology', 'sports', 'entertainment', 'regional'].includes(category);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <CategoryFilter 
        selectedCategory={state.selectedCategory} 
        onSelectCategory={setCategory} 
      />
      <NewsUpdateIndicator />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">
          {state.selectedCategory 
            ? `${state.selectedCategory.charAt(0).toUpperCase() + state.selectedCategory.slice(1)} News` 
            : 'Latest News'}
        </h1>
        
        <NewsGrid 
          articles={state.articles} 
          loading={state.loading} 
          error={state.error} 
        />
      </div>
      
      <Chatbot />
    </div>
  );
};

export default CategoryPage;