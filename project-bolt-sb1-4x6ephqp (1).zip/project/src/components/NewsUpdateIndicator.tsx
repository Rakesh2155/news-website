import React from 'react';
import { RefreshCw } from 'lucide-react';
import { useNews } from '../context/NewsContext';

const NewsUpdateIndicator: React.FC = () => {
  const { state, refreshNews } = useNews();
  const { lastUpdated } = state;

  const formatLastUpdated = () => {
    if (!lastUpdated) return 'Never';
    
    return lastUpdated.toLocaleString([], {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleRefresh = () => {
    refreshNews();
  };

  return (
    <div className="flex items-center justify-between bg-gray-100 px-4 py-2 text-sm text-gray-600 border-b">
      <div>
        <span>Last updated: {formatLastUpdated()}</span>
        <span className="ml-2 text-xs text-gray-500">(Auto-updates every 5 minutes)</span>
      </div>
      <button 
        onClick={handleRefresh}
        className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
      >
        <RefreshCw size={14} className="mr-1" />
        <span>Refresh Now</span>
      </button>
    </div>
  );
};

export default NewsUpdateIndicator;