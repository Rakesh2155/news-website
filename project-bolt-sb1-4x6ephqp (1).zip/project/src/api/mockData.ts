import { Article } from '../types';

export const mockArticles: Article[] = [
  {
    id: '1',
    title: 'PM Modi Inaugurates New AI Research Center in Delhi',
    description: 'Prime Minister Narendra Modi inaugurated the National Artificial Intelligence Research Center in New Delhi, marking a significant milestone in India\'s technological advancement.',
    content: 'Prime Minister Narendra Modi on Sunday inaugurated the National Artificial Intelligence Research Center, a state-of-the-art facility with a built-up area of 64,500 square metres. The center, which has three main research divisions, will focus on developing indigenous AI solutions for healthcare, agriculture, and education. The facility can accommodate over 500 researchers and is expected to position India as a global leader in AI research and development. "This center represents our commitment to becoming a global AI powerhouse by 2030," said PM Modi during the inauguration ceremony.',
    url: 'https://example.com/politics/modi-inaugurates-ai-center',
    image: 'https://images.unsplash.com/photo-1565674484371-599c3c11c9d1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8aW5kaWFuJTIwcGFybGlhbWVudHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=800&q=60',
    publishedAt: '2025-05-28T09:30:00Z',
    source: {
      name: 'Indian Express',
      url: 'https://indianexpress.com'
    },
    category: 'politics',
    aiSummary: 'PM Modi inaugurated the National AI Research Center in Delhi, a significant milestone for Indian technological advancement.',
    language: 'english'
  },
  {
    id: '2',
    title: 'Sensex Hits All-Time High, Crosses 100,000 Mark',
    description: 'The BSE Sensex crossed the 100,000 mark for the first time ever, driven by strong foreign institutional investor inflows and positive global cues.',
    content: 'The BSE Sensex crossed the 100,000 mark for the first time on Monday, driven by strong foreign institutional investor (FII) inflows and positive global cues. The 30-share index rose by 1,200 points, or 1.2%, to hit an all-time high of 100,048.90 in early trade. The broader NSE Nifty also surged to a record high of 30,100.20, up 380 points or 1.3%. Banking, IT, and green energy stocks led the rally, with HDFC Bank, TCS, and Adani Green Energy being the top gainers. Analysts attribute this milestone to India\'s robust economic growth, which has consistently outpaced other major economies over the past three years.',
    url: 'https://example.com/business/sensex-hits-100000',
    image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8c3RvY2slMjBtYXJrZXR8ZW58MHx8MHx8&auto=format&fit=crop&w=800&q=60',
    publishedAt: '2025-03-20T04:15:00Z',
    source: {
      name: 'Economic Times',
      url: 'https://economictimes.indiatimes.com'
    },
    category: 'business',
    aiSummary: 'Sensex crossed 100,000 for the first time, driven by strong FII inflows and positive global cues.',
    language: 'english'
  },
  {
    id: '3',
    title: 'India Successfully Tests Quantum Internet Network Across 10 Cities',
    description: 'DRDO and IIT Delhi researchers have successfully tested a quantum internet network connecting 10 major cities, marking a significant advancement in secure communications technology.',
    content: 'In a major breakthrough, researchers from the Defence Research and Development Organisation (DRDO) and Indian Institute of Technology (IIT) Delhi have successfully tested India\'s first quantum internet network connecting 10 major cities. The technology enables ultra-secure communication between multiple parties using quantum entanglement principles. This development is significant as quantum communication is considered unhackable and could revolutionize India\'s data security infrastructure. The test was conducted over a combined distance of 2,500 kilometers, setting a new record for quantum communication networks globally. "This positions India among the select few nations with operational quantum communication capabilities," said Dr. Anil Kumar, lead researcher on the project.',
    url: 'https://example.com/technology/india-quantum-internet',
    image: 'https://images.unsplash.com/photo-1639322537228-f710d846310a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8cXVhbnR1bSUyMGNvbXB1dGVyfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=800&q=60',
    publishedAt: '2025-02-18T11:45:00Z',
    source: {
      name: 'The Hindu',
      url: 'https://www.thehindu.com'
    },
    category: 'technology',
    aiSummary: 'India successfully tested a quantum internet network connecting 10 major cities, advancing secure communications.',
    language: 'english'
  },
  {
    id: '4',
    title: 'India Wins T20 World Cup 2025, Defeats Australia in Final',
    description: 'Team India clinched the T20 World Cup 2025 with a thrilling victory in the final match against Australia at the Narendra Modi Stadium in Ahmedabad.',
    content: 'Team India clinched the T20 World Cup 2025 with a thrilling 8-run victory in the final match against Australia at the Narendra Modi Stadium in Ahmedabad on Sunday. Batting first, India posted a competitive total of 203/4, with Yashasvi Jaiswal scoring a blistering 92 off 48 balls. In reply, Australia were restricted to 195/8, despite a fighting 68 from Glenn Maxwell. Jasprit Bumrah was the pick of the Indian bowlers, claiming 4 wickets for 26 runs. The victory marks India\'s second T20 World Cup win, with captain Hardik Pandya lifting the trophy amidst emotional celebrations. "This is for every Indian who has supported us through thick and thin," said Pandya in the post-match presentation.',
    url: 'https://example.com/sports/india-wins-t20-worldcup',
    image: 'https://images.unsplash.com/photo-1531415074968-036ba1b575da?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y3JpY2tldHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=800&q=60',
    publishedAt: '2025-04-26T18:30:00Z',
    source: {
      name: 'Cricbuzz',
      url: 'https://www.cricbuzz.com'
    },
    category: 'sports',
    aiSummary: 'India won the T20 World Cup 2025 with a thrilling victory against Australia in the final match.',
    language: 'english'
  },
  {
    id: '5',
    title: 'Bollywood Film "Kalki 2898 AD: The Final Chapter" Breaks Global Box Office Records',
    description: 'The sci-fi epic "Kalki 2898 AD: The Final Chapter" starring Prabhas, Deepika Padukone, and Amitabh Bachchan has broken all global box office records, collecting over ₹2,500 crore worldwide in its opening weekend.',
    content: 'The sci-fi epic "Kalki 2898 AD: The Final Chapter" directed by Nag Ashwin and starring Prabhas, Deepika Padukone, and Amitabh Bachchan has broken all global box office records, collecting over ₹2,500 crore worldwide in its opening weekend. The film, which concludes the trilogy that began in 2023, has received critical acclaim for its groundbreaking visual effects and storytelling. Trade analysts confirm that the film has become the highest-grossing Indian film ever, surpassing all previous records. The film was made on a budget of ₹1,000 crore, making it the most expensive Indian film ever produced. "This is a proud moment for Indian cinema as we\'ve created something that competes with the best of Hollywood," said producer C. Aswini Dutt.',
    url: 'https://example.com/entertainment/kalki-final-chapter-box-office',
    image: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8bW92aWUlMjB0aGVhdGVyfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=800&q=60',
    publishedAt: '2025-01-25T14:20:00Z',
    source: {
      name: 'Bollywood Hungama',
      url: 'https://www.bollywoodhungama.com'
    },
    category: 'entertainment',
    aiSummary: 'Sci-fi epic "Kalki 2898 AD: The Final Chapter" broke global box office records with ₹2,500 crore worldwide in its opening weekend.',
    language: 'english'
  },
  {
    id: '6',
    title: 'Super Cyclone Nargis Hits Tamil Nadu Coast, Evacuation of 1 Million People Underway',
    description: 'Super Cyclone Nargis made landfall on the Tamil Nadu coast near Chennai, bringing unprecedented rainfall and winds up to 220 kmph. Mass evacuation efforts are ongoing.',
    content: 'Super Cyclone Nargis made landfall on the Tamil Nadu coast near Chennai on Monday morning, bringing unprecedented rainfall and winds with speeds up to 220 kmph. The India Meteorological Department (IMD) has issued the highest level of alert for Chennai, Tiruvallur, Kancheepuram, and Chengalpattu districts. Over 1 million people are being evacuated from coastal areas and moved to relief camps in what officials are calling the largest evacuation operation in India\'s history. The Tamil Nadu government has deployed the army and national disaster response teams in affected areas. "Climate change has intensified cyclonic activity in the Bay of Bengal, and we\'re seeing storms of unprecedented strength," said Dr. M. Rajeevan, Secretary of the Ministry of Earth Sciences.',
    url: 'https://example.com/regional/cyclone-nargis',
    image: 'https://images.unsplash.com/photo-1514632595-4944383f2737?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8Y3ljbG9uZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=800&q=60',
    publishedAt: '2025-05-27T08:10:00Z',
    source: {
      name: 'The News Minute',
      url: 'https://www.thenewsminute.com'
    },
    category: 'regional',
    aiSummary: 'Super Cyclone Nargis hit Tamil Nadu coast with unprecedented rainfall and strong winds. Mass evacuation of 1 million people underway.',
    language: 'english'
  },
  {
    id: '7',
    title: 'प्रधानमंत्री मोदी ने किया राष्ट्रीय कृत्रिम बुद्धिमत्ता अनुसंधान केंद्र का उद्घाटन',
    description: 'प्रधानमंत्री नरेंद्र मोदी ने नई दिल्ली में राष्ट्रीय कृत्रिम बुद्धिमत्ता अनुसंधान केंद्र का उद्घाटन किया, जो भारत के तकनीकी विकास में एक महत्वपूर्ण मील का पत्थर है।',
    content: 'प्रधानमंत्री नरेंद्र मोदी ने रविवार को राष्ट्रीय कृत्रिम बुद्धिमत्ता अनुसंधान केंद्र का उद्घाटन किया, जो एक अत्याधुनिक सुविधा है जिसका निर्मित क्षेत्र 64,500 वर्ग मीटर है। इस केंद्र में तीन मुख्य अनुसंधान विभाग हैं, जो स्वास्थ्य सेवा, कृषि और शिक्षा के लिए स्वदेशी एआई समाधान विकसित करने पर ध्यान केंद्रित करेंगे। यह सुविधा 500 से अधिक शोधकर्ताओं को समायोजित कर सकती है और इससे भारत को एआई अनुसंधान और विकास में वैश्विक नेता के रूप में स्थापित करने की उम्मीद है। उद्घाटन समारोह के दौरान पीएम मोदी ने कहा, "यह केंद्र 2030 तक वैश्विक एआई महाशक्ति बनने की हमारी प्रतिबद्धता का प्रतिनिधित्व करता है।"',
    url: 'https://example.com/politics/modi-inaugurates-ai-center-hindi',
    image: 'https://images.unsplash.com/photo-1565674484371-599c3c11c9d1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8aW5kaWFuJTIwcGFybGlhbWVudHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=800&q=60',
    publishedAt: '2025-05-28T09:30:00Z',
    source: {
      name: 'Dainik Jagran',
      url: 'https://www.jagran.com'
    },
    category: 'politics',
    aiSummary: 'पीएम मोदी ने दिल्ली में राष्ट्रीय कृत्रिम बुद्धिमत्ता अनुसंधान केंद्र का उद्घाटन किया, जो भारतीय तकनीकी विकास के लिए एक महत्वपूर्ण मील का पत्थर है।',
    language: 'hindi'
  },
  {
    id: '8',
    title: 'சென்சேக்ஸ் அனைத்து நேரங்களிலும் உயர்ந்த அளவை எட்டியது, 100,000 மார்க்கைக் கடந்தது',
    description: 'பிஎஸ்இ சென்சேக்ஸ் முதல் முறையாக 100,000 மார்க்கைக் கடந்தது, வலுவான வெளிநாட்டு நிறுவன முதலீட்டாளர் உள்ளீடுகள் மற்றும் நேர்மறையான உலகளாவிய குறிப்புகளால் இயக்கப்பட்டது.',
    content: 'பிஎஸ்இ சென்சேக்ஸ் திங்கள்கிழமை முதல் முறையாக 100,000 மார்க்கைக் கடந்தது, வலுவான வெளிநாட்டு நிறுவன முதலீட்டாளர் (FII) உள்ளீடுகள் மற்றும் நேர்மறையான உலகளாவிய குறிப்புகளால் இயக்கப்பட்டது. 30 பங்குகளைக் கொண்ட குறியீடு 1,200 புள்ளிகள் அல்லது 1.2% உயர்ந்து, ஆரம்ப வர்த்தகத்தில் 100,048.90 என்ற அனைத்து நேரங்களிலும் உயர்ந்த அளவை எட்டியது. பரந்த NSE நிஃப்டியும் 30,100.20 என்ற சாதனை உயர்வைக் கண்டது, 380 புள்ளிகள் அல்லது 1.3% உயர்ந்தது. வங்கி, ஐடி மற்றும் பசுமை ஆற்றல் பங்குகள் பேரணியை முன்னின்று நடத்தின, HDFC வங்கி, TCS மற்றும் அதானி பசுமை ஆற்றல் ஆகியவை முன்னணி லாபம் ஈட்டியவர்களாக இருந்தன. கடந்த மூன்று ஆண்டுகளாக மற்ற முக்கிய பொருளாதாரங்களை விட தொடர்ந்து முந்திய இந்தியாவின் வலுவான பொருளாதார வளர்ச்சிக்கு இந்த மைல்கல்லை ஆய்வாளர்கள் காரணமாகக் கூறுகின்றனர்.',
    url: 'https://example.com/business/sensex-hits-100000-tamil',
    image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8c3RvY2slMjBtYXJrZXR8ZW58MHx8MHx8&auto=format&fit=crop&w=800&q=60',
    publishedAt: '2025-03-20T04:15:00Z',
    source: {
      name: 'Dinamani',
      url: 'https://www.dinamani.com'
    },
    category: 'business',
    aiSummary: 'சென்சேக்ஸ் முதல் முறையாக 100,000 ஐக் கடந்தது, வலுவான FII உள்ளீடுகள் மற்றும் நேர்மறையான உலகளாவிய குறிப்புகளால் இயக்கப்பட்டது.',
    language: 'tamil'
  },
  {
    id: '9',
    title: 'భారతదేశం T20 ప్రపంచ కప్ 2025ను గెలుచుకుంది, ఫైనల్లో ఆస్ట్రేలియాను ఓడించింది',
    description: 'టీమ్ ఇండియా అహ్మదాబాద్‌లోని నరేంద్ర మోదీ స్టేడియంలో జరిగిన ఫైనల్ మ్యాచ్‌లో ఆస్ట్రేలియాపై త్రిల్లింగ్ విక్టరీతో T20 ప్రపంచ కప్ 2025ను గెలుచుకుంది.',
    content: 'టీమ్ ఇండియా ఆదివారం అహ్మదాబాద్‌లోని నరేంద్ర మోదీ స్టేడియంలో జరిగిన ఫైనల్ మ్యాచ్‌లో ఆస్ట్రేలియాపై త్రిల్లింగ్ 8-రన్ల విక్టరీతో T20 ప్రపంచ కప్ 2025ను గెలుచుకుంది. మొదట బ్యాటింగ్ చేసిన భారత్ 203/4 పరుగులు చేసింది, యశస్వి జైస్వాల్ 48 బంతుల్లో 92 పరుగులు చేశాడు. ప్రత్యుత్తరంగా, గ్లెన్ మాక్స్‌వెల్ 68 పరుగులు చేసినప్పటికీ, ఆస్ట్రేలియా 195/8కి పరిమితమైంది. జస్ప్రీత్ బుమ్రా 26 పరుగులకు 4 వికెట్లు తీసి భారత బౌలర్లలో అత్యుత్తమంగా నిలిచాడు. ఈ విజయంతో భారత్ రెండవ T20 ప్రపంచ కప్ గెలుపొందగా, కెప్టెన్ హార్దిక్ పాండ్యా భావోద్వేగ వేడుకల మధ్య ట్రోఫీని ఎత్తుకున్నాడు. "ఇది మాకు మంచి కాలాల్లోనూ, కష్ట సమయాల్లోనూ మద్దతు ఇచ్చిన ప్రతి భారతీయుడి కోసం," అని పాండ్యా మ్యాచ్ అనంతర ప్రదర్శనలో అన్నాడు.',
    url: 'https://example.com/sports/india-wins-t20-worldcup-telugu',
    image: 'https://images.unsplash.com/photo-1531415074968-036ba1b575da?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y3JpY2tldHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=800&q=60',
    publishedAt: '2025-04-26T18:30:00Z',
    source: {
      name: 'Eenadu',
      url: 'https://www.eenadu.net'
    },
    category: 'sports',
    aiSummary: 'భారతదేశం ఫైనల్ మ్యాచ్‌లో ఆస్ట్రేలియాపై త్రిల్లింగ్ విక్టరీతో T20 ప్రపంచ కప్ 2025ను గెలుచుకుంది.',
    language: 'telugu'
  },
  {
    id: '10',
    title: 'Indian Startup Raises $500 Million to Develop AI-Powered Healthcare Solutions',
    description: 'Bengaluru-based healthcare startup MedAssist AI has raised $500 million in Series D funding to expand its AI-powered diagnostic tools across Asia and Africa.',
    content: 'Bengaluru-based healthcare startup MedAssist AI has raised $500 million in Series D funding led by SoftBank Vision Fund, with participation from existing investors Sequoia Capital India, Accel and Chiratae Ventures. The company plans to use the funds to expand its AI-powered diagnostic tools across Asia and Africa, where access to healthcare specialists is limited. MedAssist AI\'s flagship product is a portable device that can diagnose over 50 common illnesses using AI algorithms and provide treatment recommendations. The company claims that its technology has already been deployed in over 5,000 primary health centers across 15 countries and has helped diagnose over 10 million patients. "This funding will help us reach our goal of serving 100 million patients by 2027," said Priya Sharma, CEO of MedAssist AI. The company is now valued at $3.5 billion, making it one of India\'s most valuable healthtech unicorns.',
    url: 'https://example.com/technology/medassist-funding',
    image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aGVhbHRoY2FyZSUyMHRlY2hub2xvZ3l8ZW58MHx8MHx8&auto=format&fit=crop&w=800&q=60',
    publishedAt: '2025-04-22T10:05:00Z',
    source: {
      name: 'YourStory',
      url: 'https://yourstory.com'
    },
    category: 'technology',
    aiSummary: 'Bengaluru-based MedAssist AI raised $500M to expand AI diagnostic tools across Asia and Africa where specialists are limited.',
    language: 'english'
  }
];