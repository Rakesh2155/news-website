import axios from 'axios';
import { Article, Category, Language } from '../types';

// In a real application, you would use environment variables for API keys
const NEWS_API_KEY = 'YOUR_NEWS_API_KEY';
const NEWS_API_URL = 'https://newsapi.org/v2';

// Mock data for development (since we don't have actual API keys)
import { mockArticles } from './mockData';

// Function to simulate new articles being added over time
const getRandomArticle = (existingArticles: Article[]): Article => {
  // Get a random article from mock data and modify it to simulate a new article
  const baseArticle = mockArticles[Math.floor(Math.random() * mockArticles.length)];
  const existingIds = existingArticles.map(a => a.id);
  
  // Create a new ID that doesn't exist in the current articles
  let newId = String(Math.floor(Math.random() * 1000));
  while (existingIds.includes(newId)) {
    newId = String(Math.floor(Math.random() * 1000));
  }
  
  // Create a modified version of the article with a new ID and timestamp
  const currentDate = new Date();
  return {
    ...baseArticle,
    id: newId,
    title: `[BREAKING] ${baseArticle.title}`,
    publishedAt: currentDate.toISOString(),
    aiSummary: `Latest update (${currentDate.toLocaleString()}): ${baseArticle.aiSummary}`
  };
};

// Simulate a growing dataset over time
let dynamicMockArticles = [...mockArticles];

// Occasionally add new articles to the mock data (for demo purposes)
const maybeAddNewArticle = () => {
  // 30% chance of adding a new article on each fetch
  if (Math.random() < 0.3) {
    const newArticle = getRandomArticle(dynamicMockArticles);
    dynamicMockArticles = [newArticle, ...dynamicMockArticles];
    console.log('New article added:', newArticle.title);
    
    // Keep the array at a reasonable size
    if (dynamicMockArticles.length > 30) {
      dynamicMockArticles = dynamicMockArticles.slice(0, 30);
    }
  }
};

export const fetchNews = async (
  category: Category = 'trending',
  language: Language = 'english',
  query: string = ''
): Promise<Article[]> => {
  // In a real application, you would use the actual API
  // const response = await axios.get(`${NEWS_API_URL}/top-headlines`, {
  //   params: {
  //     country: 'in',
  //     category: category === 'trending' ? '' : category,
  //     q: query,
  //     apiKey: NEWS_API_KEY,
  //     language: mapLanguageToApiParam(language),
  //   },
  // });
  // return mapResponseToArticles(response.data.articles, category, language);

  // For development, we'll use mock data
  return new Promise((resolve) => {
    setTimeout(() => {
      // Simulate new articles being added
      maybeAddNewArticle();
      
      let filteredArticles = [...dynamicMockArticles];
      
      if (category && category !== 'trending') {
        filteredArticles = filteredArticles.filter(article => article.category === category);
      }
      
      if (language) {
        filteredArticles = filteredArticles.filter(article => article.language === language);
      }
      
      if (query) {
        const lowerQuery = query.toLowerCase();
        filteredArticles = filteredArticles.filter(
          article => 
            article.title.toLowerCase().includes(lowerQuery) || 
            article.description.toLowerCase().includes(lowerQuery)
        );
      }
      
      resolve(filteredArticles);
    }, 500); // Simulate network delay
  });
};

export const fetchTrendingNews = async (language: Language = 'english'): Promise<Article[]> => {
  // In a real application, you would fetch trending news
  // For now, we'll just return the top 5 articles from mock data
  const allArticles = await fetchNews('trending', language);
  return allArticles.slice(0, 5);
};

// Helper function to map our language types to API parameters
const mapLanguageToApiParam = (language: Language): string => {
  switch (language) {
    case 'english': return 'en';
    case 'hindi': return 'hi';
    case 'tamil': return 'ta';
    case 'telugu': return 'te';
    case 'bengali': return 'bn';
    case 'marathi': return 'mr';
    default: return 'en';
  }
};

// Helper function to generate AI summaries (in a real app, this would call an AI service)
export const generateAISummary = async (article: Article): Promise<string> => {
  // In a real application, you would call an AI service like OpenAI
  // For now, we'll just return a shortened version of the description
  return article.description.split(' ').slice(0, 15).join(' ') + '...';
};