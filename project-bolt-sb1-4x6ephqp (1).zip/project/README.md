# BharatNews - AI-Powered Indian News Platform

BharatNews is a modern news platform that delivers the latest updates from across India in multiple languages, powered by AI for quick reading and personalized updates.

## Deployment Instructions for Render.com

1. Create a Render.com account at https://render.com if you don't have one already
2. Click on "New +" button in the dashboard and select "Blueprint" from the dropdown
3. Connect your GitHub/GitLab repository containing this project
4. Render will automatically detect the `render.yaml` file and configure the deployment
5. Click "Apply" to start the deployment process
6. Once deployed, Render will provide you with a URL to access your application

## Features

- Latest news from across India
- Multiple language support (English, Hindi, Tamil, Telugu, Bengali, Marathi)
- AI-powered news summaries
- Category-based filtering
- Responsive design for all devices
- Real-time updates
- Interactive chatbot assistant

## Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```